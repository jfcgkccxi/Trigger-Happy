SMODS.Joker{ --Summoning Circle
    key = "summoningcircle",
    config = {
        extra = {
            counter = 3,
            currentmoney = 0,
            mostrecenthandlevel = 0,
            jokercount = 0,
            enhancedcardsindeck = 0,
            hands = 1,
            dollars = 10,
            levels = 1,
            mult = 20,
            round = 0,
            respect = 0
        }
    },
    loc_txt = {
        ['name'] = 'Summoning Circle',
        ['text'] = {
            [1] = 'Every third {C:attention}5{} scored',
            [2] = 'gives something you {C:red}lack{}',
            [3] = '({C:blue}Hands{}, {C:attention}Money{}, {C:green}Levels{},',
            [4] = '{C:spades}Jokers{}, {C:tarot}Cards{}, or {C:red}+Mult{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["triggerh_triggerh_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 5 and (card.ability.extra.counter or 0) <= 1 and G.GAME.current_round.hands_left == 0) then
                card.ability.extra.counter = (card.ability.extra.counter) + 2
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Final Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end
                }
            elseif (context.other_card:get_id() == 5 and (card.ability.extra.counter or 0) <= 1 and G.GAME.dollars < 25) then
                card.ability.extra.counter = (card.ability.extra.counter) + 2
                return {
                    dollars = card.ability.extra.dollars,
                    message = "<$25"
                }
            elseif (context.other_card:get_id() == 5 and (card.ability.extra.counter or 0) <= 1 and (G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level or 0) < 5) then
                local target_hand = (context.scoring_name or "High Card")
                card.ability.extra.counter = (card.ability.extra.counter) + 2
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = "<5 Lvl"
                }
            elseif (context.other_card:get_id() == 5 and (card.ability.extra.counter or 0) <= 1 and #(G.jokers and G.jokers.cards or {}) < 5) then
                local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker' })
                          if joker_card then
                              
                              
                          end
                          G.GAME.joker_buffer = 0
                          return true
                      end
                  }))
                  end
                card.ability.extra.counter = (card.ability.extra.counter) + 2
                return {
                    message = "<5 Jokers"
                }
            elseif (context.other_card:get_id() == 5 and (card.ability.extra.counter or 0) <= 1 and (function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)() < 8) then
                local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = pseudorandom_element({G.P_CENTERS.m_gold, G.P_CENTERS.m_steel, G.P_CENTERS.m_glass, G.P_CENTERS.m_wild, G.P_CENTERS.m_mult, G.P_CENTERS.m_lucky, G.P_CENTERS.m_stone}, pseudoseed('add_card_hand_enhancement'))
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function() 
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        return true
                    end
                }))
                card.ability.extra.counter = (card.ability.extra.counter) + 2
                return {
                    message = "<8 Enhanced"
                }
            elseif (context.other_card:get_id() == 5 and (card.ability.extra.counter or 0) <= 1) then
                card.ability.extra.counter = (card.ability.extra.counter) + 2
                return {
                    mult = card.ability.extra.mult
                }
            elseif context.other_card:get_id() == 5 then
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
            end
        end
    end
}
SMODS.Joker{ --Rebellion
    key = "rebellion",
    config = {
        extra = {
            rebellion = 0,
            rebellion2 = 0,
            rebellion3 = 0,
            rebellion4 = 0,
            rebellion5 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Rebellion',
        ['text'] = {
            [1] = 'Played {C:attention}Steel{} cards',
            [2] = '{C:attention}retrigger {}the card',
            [3] = 'to the right'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play and not context.blueprint then
            if (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[2]) then
                return {
                    repetitions = card.ability.extra.rebellion,
                    message = localize('k_again_ex')
                }
            elseif (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[3]) then
                return {
                    repetitions = card.ability.extra.rebellion2,
                    message = localize('k_again_ex')
                }
            elseif (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[4]) then
                return {
                    repetitions = card.ability.extra.rebellion3,
                    message = localize('k_again_ex')
                }
            elseif (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[5]) then
                return {
                    repetitions = card.ability.extra.rebellion4,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[2] then
                return {
                    repetitions = card.ability.extra.rebellion,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[3] then
                return {
                    repetitions = card.ability.extra.rebellion2,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[4] then
                return {
                    repetitions = card.ability.extra.rebellion3,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[5] then
                return {
                    repetitions = card.ability.extra.rebellion4,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[1]) then
                card.ability.extra.rebellion = (card.ability.extra.rebellion) + 1
            elseif (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[2]) then
                card.ability.extra.rebellion2 = (card.ability.extra.rebellion2) + 1
            elseif (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[3]) then
                card.ability.extra.rebellion3 = (card.ability.extra.rebellion3) + 1
            elseif (SMODS.get_enhancements(context.other_card)["m_steel"] == true and context.other_card == context.scoring_hand[4]) then
                card.ability.extra.rebellion4 = (card.ability.extra.rebellion4) + 1
            end
        end
        if context.after and context.cardarea == G.jokers  and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.rebellion = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.rebellion2 = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.rebellion3 = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.rebellion4 = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.rebellion5 = 0
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                        }
                        }
                }
        end
    end
}
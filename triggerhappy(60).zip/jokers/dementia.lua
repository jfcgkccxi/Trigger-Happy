SMODS.Joker{ --Dementia
    key = "dementia",
    config = {
        extra = {
            odds = 4,
            ante_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Dementia',
        ['text'] = {
            [1] = '{C:attention}Skipping {}a blind has a',
            [2] = '{C:green}#1# in #2#{} chance to... wait',
            [3] = 'what did this do again?'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_triggerh_dementia') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.skip_blind  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_6bc7deda', 1, card.ability.extra.odds, 'j_triggerh_dementia', false) then
              SMODS.calculate_effect({func = function()
                    local mod = -card.ability.extra.ante_value
		ease_ante(mod)
		G.E_MANAGER:add_event(Event({
			func = function()
				G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
				return true
			end,
		}))
                    return true
                end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Huh?", colour = G.C.FILTER})
          end
            end
        end
    end
}
SMODS.Joker{ --Unstoppable Force
    key = "unstoppableforce",
    config = {
        extra = {
            force = 0
        }
    },
    loc_txt = {
        ['name'] = 'Unstoppable Force',
        ['text'] = {
            [1] = '{C:attention}4{}\'s gain {C:red}+2{} Mult for',
            [2] = 'each scored {C:attention}4{} this round',
            [3] = '(Currently {C:red}+#1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.force}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 4 then
                card.ability.extra.force = (card.ability.extra.force) + 2
                return {
                    mult = card.ability.extra.force
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.force = 0
                    return true
                end
                }
        end
    end
}
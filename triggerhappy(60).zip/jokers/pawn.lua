SMODS.Joker{ --Pawn
    key = "pawn",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Pawn',
        ['text'] = {
            [1] = 'Playing a {C:attention}2{} {C:red}removes{} its Enhancement,',
            [2] = 'creating a random {C:purple}Tarot{} card'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 and (function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)()) then
                context.other_card:set_ability(G.P_CENTERS.c_base)
                local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', soulable = undefined, key = nil, key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    message = "Card Modified!",
                    extra = {
                        message = created_consumable and localize('k_plus_tarot') or nil,
                        colour = G.C.PURPLE
                        }
                }
            end
        end
    end
}
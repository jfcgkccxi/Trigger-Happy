SMODS.Joker{ --Murasama
    key = "murasama",
    config = {
        extra = {
            hand_change = 1,
            firsthand = 1,
            repetitions = 2
        }
    },
    loc_txt = {
        ['name'] = 'Murasama',
        ['text'] = {
            [1] = '{C:red}-1{} Hand',
            [2] = '{C:attention}Retriggers {}the',
            [3] = 'first hand twice'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if (card.ability.extra.firsthand or 0) == 1 then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.first_hand_drawn  then
                return {
                    message = "Active!",
                    extra = {
                        func = function()
                    card.ability.extra.firsthand = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.firsthand = 0
                    return true
                end
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.GAME.round_resets.hands = math.max(1, G.GAME.round_resets.hands - card.ability.extra.hand_change)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.hand_change
    end
}
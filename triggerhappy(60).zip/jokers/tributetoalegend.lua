SMODS.Joker{ --Tribute to a Legend
    key = "tributetoalegend",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Tribute to a Legend',
        ['text'] = {
            [1] = 'Gains {X:red,C:white}0.25X{} every',
            [2] = '{C:attention}Gold{} card cashed',
            [3] = '(Currently {X:red,C:white}X#1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.25
                    return true
                end,
                    message = "X0.25"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
        if context.individual and context.cardarea == G.play  then
            if ((function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_ticket" then
              return true
          end
      end
      return false
  end)() and SMODS.get_enhancements(context.other_card)["m_gold"] == true) then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.25
                return {
                    message = "X0.25"
                }
            end
        end
    end
}
SMODS.Joker{ --House of Cards
    key = "houseofcards",
    config = {
        extra = {
            xmultvar = 1,
            odds = 2
        }
    },
    loc_txt = {
        ['name'] = 'House of Cards',
        ['text'] = {
            [1] = 'Each {C:attention}Full House{} gains {X:red,C:white}X0.5{}{C:white}{} Mult,',
            [2] = 'not playing {C:attention}Full House {}has a',
            [3] = '{C:green}#2# in #3#{} chance to reset.',
            [4] = '(Currently {X:red,C:white}X#1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_triggerh_houseofcards') 
        return {vars = {card.ability.extra.xmultvar, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Full House"]) then
                card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.5
                return {
                    Xmult = card.ability.extra.xmultvar
                }
            elseif true then
                return {
                    Xmult = card.ability.extra.xmultvar
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_69130e33', 1, card.ability.extra.odds, 'j_triggerh_houseofcards', false) then
              card.ability.extra.xmultvar = 1
                        
          end
                        return true
                    end
                }
            end
        end
    end
}
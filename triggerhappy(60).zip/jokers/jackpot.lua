SMODS.Joker{ --Jackpot
    key = "jackpot",
    config = {
        extra = {
            odds = 25,
            dollars = 100
        }
    },
    loc_txt = {
        ['name'] = 'Jackpot',
        ['text'] = {
            [1] = '{C:attention}Rerolling {}has a',
            [2] = '{C:green}#1# in #2#{} chance',
            [3] = 'to earn {C:money}$100{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_triggerh_jackpot') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.reroll_shop  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_69debf63', 1, card.ability.extra.odds, 'j_triggerh_jackpot', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars}, card)
          end
            end
        end
    end
}
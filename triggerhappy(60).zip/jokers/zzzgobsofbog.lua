SMODS.Joker{ --Gobsofbog
    key = "zzzgobsofbog",
    config = {
        extra = {
            counter = 5,
            mult = 50,
            Xmult = 1.5,
            Xmult2 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Gobsofbog',
        ['text'] = {
            [1] = 'Scored {C:attention}Stone{} cards',
            [2] = 'are worth {X:red,C:white}X1.5{}',
            [3] = 'Every {C:blue}5{}th {C:attention}Stone{} card',
            [4] = 'scores {C:red}{C:red}+50{}{} Mult',
            [5] = '({C:inactive}#1# remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 1,
        y = 3
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.counter}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_stone"] == true and (card.ability.extra.counter or 0) <= 1) then
                card.ability.extra.counter = 5
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        Xmult = card.ability.extra.Xmult
                        }
                }
            elseif (SMODS.get_enhancements(context.other_card)["m_stone"] == true and (card.ability.extra.counter or 0) > 1) then
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                return {
                    Xmult = card.ability.extra.Xmult2
                }
            end
        end
    end
}
SMODS.Joker{ --Reaper
    key = "reaper",
    config = {
        extra = {
            counter = 3,
            repetitions = 2
        }
    },
    loc_txt = {
        ['name'] = 'Reaper',
        ['text'] = {
            [1] = 'Every {C:blue}third hand{},',
            [2] = '{C:attention}retrigger{} all cards',
            [3] = 'in hand {C:attention}twice{}',
            [4] = '({C:inactive}#1# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.counter}}
    end,

    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.counter or 0) <= 1 then
                return {
                    func = function()
                    card.ability.extra.counter = 3
                    return true
                end
                }
            elseif (card.ability.extra.counter or 0) == 2 then
                return {
                    message = "Active!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            else
                return {
                    func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if (card.ability.extra.counter or 0) == 1 then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}
SMODS.Joker{ --Recursion
    key = "recursion",
    config = {
        extra = {
            uno = 0,
            dos = 0,
            tres = 0,
            cuarto = 0,
            cinco = 0,
            seis = 0,
            siete = 0,
            ocho = 0,
            nueve = 0,
            diez = 0,
            Xmult = 11,
            Xmult2 = 10,
            Xmult3 = 9,
            Xmult4 = 8,
            Xmult5 = 7,
            Xmult6 = 6,
            Xmult7 = 5,
            Xmult8 = 4,
            Xmult9 = 3,
            Xmult10 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Recursion',
        ['text'] = {
            [1] = 'Scoring X {}cards of',
            [2] = 'X rank grants {X:red,C:white}X{} Mult',
            [3] = '(Ex. 3 3s grants {X:red,C:white}X3{})',
            [4] = '{C:inactive,s:0.9}(Includes retriggers){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if context.other_card:get_id() == 2 then
                card.ability.extra.dos = (card.ability.extra.dos) + 1
            elseif context.other_card:get_id() == 3 then
                card.ability.extra.tres = (card.ability.extra.tres) + 1
            elseif context.other_card:get_id() == 4 then
                card.ability.extra.cuarto = (card.ability.extra.cuarto) + 1
            elseif context.other_card:get_id() == 5 then
                card.ability.extra.cinco = (card.ability.extra.cinco) + 1
            elseif context.other_card:get_id() == 6 then
                card.ability.extra.seis = (card.ability.extra.seis) + 1
            elseif context.other_card:get_id() == 7 then
                card.ability.extra.siete = (card.ability.extra.siete) + 1
            elseif context.other_card:get_id() == 8 then
                card.ability.extra.ocho = (card.ability.extra.ocho) + 1
            elseif context.other_card:get_id() == 9 then
                card.ability.extra.nueve = (card.ability.extra.nueve) + 1
            elseif context.other_card:get_id() == 10 then
                card.ability.extra.diez = (card.ability.extra.diez) + 1
            elseif context.other_card:get_id() == 14 then
                card.ability.extra.uno = (card.ability.extra.uno) + 1
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.uno = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.dos = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.tres = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.cuarto = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.cinco = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.seis = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.siete = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.ocho = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.nueve = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.diez = 0
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.uno or 0) >= 11 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            elseif (card.ability.extra.diez or 0) >= 10 then
                return {
                    Xmult = card.ability.extra.Xmult2
                }
            elseif (card.ability.extra.nueve or 0) >= 9 then
                return {
                    Xmult = card.ability.extra.Xmult3
                }
            elseif (card.ability.extra.ocho or 0) >= 8 then
                return {
                    Xmult = card.ability.extra.Xmult4
                }
            elseif (card.ability.extra.siete or 0) >= 7 then
                return {
                    Xmult = card.ability.extra.Xmult5
                }
            elseif (card.ability.extra.seis or 0) >= 6 then
                return {
                    Xmult = card.ability.extra.Xmult6
                }
            elseif (card.ability.extra.cinco or 0) >= 5 then
                return {
                    Xmult = card.ability.extra.Xmult7
                }
            elseif (card.ability.extra.cuarto or 0) >= 4 then
                return {
                    Xmult = card.ability.extra.Xmult8
                }
            elseif (card.ability.extra.tres or 0) >= 3 then
                return {
                    Xmult = card.ability.extra.Xmult9
                }
            elseif (card.ability.extra.dos or 0) >= 2 then
                return {
                    Xmult = card.ability.extra.Xmult10
                }
            end
        end
    end
}
SMODS.Joker{ --King Cerberus
    key = "kingcerberus",
    config = {
        extra = {
            theshitihavetodo = 1
        }
    },
    loc_txt = {
        ['name'] = 'King Cerberus',
        ['text'] = {
            [1] = 'Playing a Flush of',
            [2] = '{C:attention}#3#s{} creates a',
            [3] = '{C:purple}Wheel of Fortune{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.theshitihavetodo, localize((G.GAME.current_round.suitvar_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.suitvar_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suitvar_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.theshitihavetodo = pseudorandom('theshitihavetodo_89e2d310', 1, 4)
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (next(context.poker_hands["Flush"]) and (function()
    local suitCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit(G.GAME.current_round.suitvar_card.suit) then
            suitCount = suitCount + 1
        end
    end
    
    return suitCount >= 4
end)()) then
                local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', soulable = undefined, key = 'c_wheel_of_fortune', key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    message = "Wheel!"
                }
            end
        end
        if context.first_hand_drawn  then
            if (card.ability.extra.theshitihavetodo or 0) == 1 then
                G.GAME.current_round.suitvar_card.suit = 'Spades'
                return {
                    message = "Spades!"
                }
            elseif (card.ability.extra.theshitihavetodo or 0) == 2 then
                G.GAME.current_round.suitvar_card.suit = 'Hearts'
                return {
                    message = "Hearts!"
                }
            elseif (card.ability.extra.theshitihavetodo or 0) == 3 then
                G.GAME.current_round.suitvar_card.suit = 'Clubs'
                return {
                    message = "Clubs!"
                }
            elseif (card.ability.extra.theshitihavetodo or 0) == 4 then
                G.GAME.current_round.suitvar_card.suit = 'Diamonds'
                return {
                    message = "Diamonds!"
                }
            end
        end
        if context.setting_blind  then
                return {
                    func = function()
                    card.ability.extra.theshitihavetodo = pseudorandom('theshitihavetodo_fd8842ac', 1, 4)
                    return true
                end
                }
        end
    end
}
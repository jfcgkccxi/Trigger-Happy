SMODS.Joker{ --Spider Web
    key = "spiderweb",
    config = {
        extra = {
            stock = 0
        }
    },
    loc_txt = {
        ['name'] = 'Spider Web',
        ['text'] = {
            [1] = 'Stocks {C:blue}+25 Chips{}',
            [2] = 'each {C:attention}8{} scored',
            [3] = 'released on {C:blue}Final Hand{}',
            [4] = '(Currently {C:blue}+#1#{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["triggerh_triggerh_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.stock}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 8 then
                card.ability.extra.stock = (card.ability.extra.stock) + 25
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.current_round.hands_left <= 0 and (card.ability.extra.stock or 0) > 0) then
                local stock_value = card.ability.extra.stock
                card.ability.extra.stock = 0
                return {
                    chips = stock_value
                }
            end
        end
    end
}
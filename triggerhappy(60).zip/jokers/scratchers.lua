SMODS.Joker{ --Scratchers
    key = "scratchers",
    config = {
        extra = {
            cost = 0,
            repetitions_min = 1,
            repetitions_max = 2
        }
    },
    loc_txt = {
        ['name'] = 'Scratchers',
        ['text'] = {
            [1] = '{C:attention}Lucky{} cards retrigger',
            [2] = '{C:attention}1-2{} times,',
            [3] = '{C:red}-$1{} per trigger'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_lucky"] == true then
                return {
                    repetitions = pseudorandom('repetitions_44cfbf36', card.ability.extra.repetitions_min, card.ability.extra.repetitions_max),
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_lucky"] == true then
                card.ability.extra.cost = (card.ability.extra.cost) + 1
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.cost or 0) > 0 then
                local cost_value = card.ability.extra.cost
                return {
                    dollars = -cost_value,
                    extra = {
                        func = function()
                    card.ability.extra.cost = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
    end
}
SMODS.Joker{ --Hitman
    key = "hitman",
    config = {
        extra = {
            counter = 3,
            dollars = 4
        }
    },
    loc_txt = {
        ['name'] = 'Hitman',
        ['text'] = {
            [1] = 'Every {C:blue}third hand{},',
            [2] = 'scoring a {C:attention}Face Card',
            [3] = '{}of{C:attention} #2#s {}earns {C:attention}$4{}',
            [4] = '({C:inactive}#1# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.counter, localize((G.GAME.current_round.suit_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.suit_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suit_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.counter or 0) == 1 then
                if G.playing_cards then
                    local valid_suit_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suit_cards[#valid_suit_cards + 1] = v
                        end
                    end
                    if valid_suit_cards[1] then
                        local suit_card = pseudorandom_element(valid_suit_cards, pseudoseed('suit' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suit_card.suit = suit_card.base.suit
                    end
                end
                card.ability.extra.counter = 3
            elseif (card.ability.extra.counter or 0) == 2 then
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                return {
                    message = "Active!"
                }
            else
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
            end
        end
        if context.individual and context.cardarea == G.play  then
            if ((card.ability.extra.counter or 0) == 1 and context.other_card:is_face() and context.other_card:is_suit(G.GAME.current_round.suit_card.suit)) then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}
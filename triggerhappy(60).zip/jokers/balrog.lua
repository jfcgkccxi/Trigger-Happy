SMODS.Joker{ --Balrog
    key = "balrog",
    config = {
        extra = {
            stonemult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Balrog',
        ['text'] = {
            [1] = 'Gains {C:red}+4{} Mult per {C:attention}Stone{}',
            [2] = 'card scored. {C:attention}Resets {}upon',
            [3] = 'selecting Small Blind.',
            [4] = '{C:inactive}(Currently {C:red}+#1#{}){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.stonemult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                card.ability.extra.stonemult = (card.ability.extra.stonemult) + 4
                return {
                    message = "+4"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.stonemult
                }
        end
        if context.setting_blind  then
            if G.GAME.blind:get_type() == 'Small' then
                return {
                    func = function()
                    card.ability.extra.stonemult = 0
                    return true
                end,
                    message = "Reset!"
                }
            end
        end
    end
}
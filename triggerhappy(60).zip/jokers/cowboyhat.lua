SMODS.Joker{ --Cowboy Hat
    key = "cowboyhat",
    config = {
        extra = {
            discards = 1,
            dollars = 4,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cowboy Hat',
        ['text'] = {
            [1] = 'Running out of',
            [2] = '{C:red}discards {}takes {C:money}$4{}',
            [3] = 'and gives {C:red}+1 Discard{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.hand_drawn  then
            if G.GAME.current_round.discards_left <= 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discards).." Discard", colour = G.C.ORANGE})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.discards
                return true
            end,
                    extra = {
                        dollars = -card.ability.extra.dollars,
                        colour = G.C.MONEY
                        }
                }
            end
        end
    end
}
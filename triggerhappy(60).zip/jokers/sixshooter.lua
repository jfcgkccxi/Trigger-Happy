SMODS.Joker{ --Six Shooter
    key = "sixshooter",
    config = {
        extra = {
            sixshooter = 1,
            lag = 1
        }
    },
    loc_txt = {
        ['name'] = 'Six Shooter',
        ['text'] = {
            [1] = 'Next hand gains {X:red,C:white}X0.6{}',
            [2] = 'every {C:attention}6{} scored',
            [3] = '(Currently {X:red,C:white}X#1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.sixshooter}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 6 then
                card.ability.extra.sixshooter = (card.ability.extra.sixshooter) + 0.6
                return {
                    message = "+0.6"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.lag
                }
        end
        if context.hand_drawn  then
                local sixshooter_value = card.ability.extra.sixshooter
                return {
                    func = function()
                    card.ability.extra.lag = card.ability.extra.sixshooter
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.sixshooter = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
        end
    end
}
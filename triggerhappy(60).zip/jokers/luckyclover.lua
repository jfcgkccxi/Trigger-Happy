SMODS.Joker{ --Lucky Clover
    key = "luckyclover",
    config = {
        extra = {
            clover = 0,
            cloverturn = 0,
            easteregg = 5,
            cloversuck = 0,
            anteactive = 1,
            numerator = 0,
            denominator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Lucky Clover',
        ['text'] = {
            [1] = 'Every other {C:attention}7{} scored',
            [2] = 'ups all chance values by 1',
            [3] = 'until next hand.',
            [4] = '(Ex. {C:green}1 in 2{} = {C:green}2 in 3{})',
            [5] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
          if context.mod_probability  then
          local numerator, denominator = context.numerator, context.denominator
                  numerator = numerator + card.ability.extra.clover
                denominator = denominator + card.ability.extra.clover
        return {
          numerator = numerator, 
          denominator = denominator
        }
          end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 7 and (card.ability.extra.cloverturn or 0) >= 1) then
                card.ability.extra.clover = (card.ability.extra.clover) + 1
            elseif context.other_card:get_id() == 7 then
                card.ability.extra.cloverturn = (card.ability.extra.cloverturn) + 1
            end
        end
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.clover = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.cloverturn = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
        end
        if context.hand_drawn  then
                return {
                    func = function()
                    card.ability.extra.clover = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.cloverturn = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
        end
    end
}
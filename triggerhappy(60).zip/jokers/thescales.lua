SMODS.Joker{ --The Scales
    key = "thescales",
    config = {
        extra = {
            hot = 10,
            cold = 25
        }
    },
    loc_txt = {
        ['name'] = 'The Scales',
        ['text'] = {
            [1] = '{C:spades}Black {}cards add {C:blue}+5{} Chips and {C:red}-2{} Mult.',
            [2] = '{C:red}Red{} cards add {C:blue}-5{} Chips and {C:red}+2{} Mult.',
            [3] = '(Currently {C:blue}#2#{} and{C:red} #1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.hot, card.ability.extra.cold}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.cold,
                    extra = {
                        mult = card.ability.extra.hot
                        }
                }
        end
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                card.ability.extra.hot = (card.ability.extra.hot) + 0
                card.ability.extra.cold = (card.ability.extra.cold) + 0
            elseif context.other_card:is_suit("Hearts") or context.other_card:is_suit("Diamonds") then
                card.ability.extra.hot = (card.ability.extra.hot) + 2
                card.ability.extra.cold = (card.ability.extra.cold) + -5
            elseif context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") then
                card.ability.extra.hot = (card.ability.extra.hot) + -2
                card.ability.extra.cold = (card.ability.extra.cold) + 5
            end
        end
    end
}
SMODS.Joker{ --Prideful Joker
    key = "pridefuljoker",
    config = {
        extra = {
            counter = 1,
            mult = 8,
            mult2 = 8,
            mult3 = 8,
            mult4 = 8
        }
    },
    loc_txt = {
        ['name'] = 'Prideful Joker',
        ['text'] = {
            [1] = 'Scored {C:attention}#2#{} cards are',
            [2] = 'worth {C:red}+8{} Mult',
            [3] = '(Cycles {C:spades}S{}, {C:hearts}H{}, {C:clubs}C{}, {C:diamonds}D{})',
            [4] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.counter, localize((G.GAME.current_round.pride_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.pride_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.pride_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Spades") and (card.ability.extra.counter or 0) == 1) then
                G.GAME.current_round.pride_card.suit = 'Hearts'
                card.ability.extra.counter = (card.ability.extra.counter) + 1
                return {
                    mult = card.ability.extra.mult
                }
            elseif (context.other_card:is_suit("Hearts") and (card.ability.extra.counter or 0) == 2) then
                G.GAME.current_round.pride_card.suit = 'Clubs'
                card.ability.extra.counter = (card.ability.extra.counter) + 1
                return {
                    mult = card.ability.extra.mult2
                }
            elseif (context.other_card:is_suit("Clubs") and (card.ability.extra.counter or 0) == 3) then
                G.GAME.current_round.pride_card.suit = 'Diamonds'
                card.ability.extra.counter = (card.ability.extra.counter) + 1
                return {
                    mult = card.ability.extra.mult3
                }
            elseif (context.other_card:is_suit("Diamonds") and (card.ability.extra.counter or 0) == 4) then
                G.GAME.current_round.pride_card.suit = 'Spades'
                card.ability.extra.counter = 1
                return {
                    mult = card.ability.extra.mult4
                }
            end
        end
    end
}
SMODS.Joker{ --Skipping Stone
    key = "skippingstone",
    config = {
        extra = {
            skippingstone = 0,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Skipping Stone',
        ['text'] = {
            [1] = '{C:attention}Skipping {}a Blind gives {C:blue}+2 Hands{}',
            [2] = 'for the next Blind'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.skip_blind  and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.skippingstone = (card.ability.extra.skippingstone) + 2
                    return true
                end
                }
        end
        if context.setting_blind  then
            if (card.ability.extra.skippingstone or 0) > 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.skippingstone).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.skippingstone
                return true
            end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.skippingstone = 0
                    return true
                end
                }
        end
    end
}
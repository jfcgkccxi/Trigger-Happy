SMODS.Joker{ --Summoned Swords
    key = "summonedswords",
    config = {
        extra = {
            retrig = 0,
            one = 0,
            two = 0,
            three = 0,
            four = 0
        }
    },
    loc_txt = {
        ['name'] = 'Summoned Swords',
        ['text'] = {
            [1] = '{C:attention}Retriggers {}cards X times',
            [2] = 'based on {C:blue}hand{}:',
            [3] = '{C:blue}Four of a Kind{}: 1',
            [4] = '{C:common}Three of a Kind{}: 2',
            [5] = '{C:clubs}Pair{}: 3',
            [6] = '{C:enhanced}High Card{}: 4',
            [7] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    repetitions = card.ability.extra.one,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[2] then
                return {
                    repetitions = card.ability.extra.two,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[3] then
                return {
                    repetitions = card.ability.extra.three,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[4] then
                return {
                    repetitions = card.ability.extra.four,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.one = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.two = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.three = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.four = 0
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                        }
                }
        end
        if context.before and context.cardarea == G.jokers  and not context.blueprint then
            if context.scoring_name == "High Card" then
                return {
                    func = function()
                    card.ability.extra.one = (card.ability.extra.one) + 4
                    return true
                end
                }
            elseif context.scoring_name == "Pair" then
                return {
                    func = function()
                    card.ability.extra.one = (card.ability.extra.one) + 3
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.two = (card.ability.extra.two) + 3
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            elseif context.scoring_name == "Three of a Kind" then
                return {
                    func = function()
                    card.ability.extra.one = (card.ability.extra.one) + 2
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.two = (card.ability.extra.two) + 2
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.three = (card.ability.extra.three) + 2
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
            elseif context.scoring_name == "Four of a Kind" then
                return {
                    func = function()
                    card.ability.extra.one = (card.ability.extra.one) + 1
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.two = (card.ability.extra.two) + 1
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.three = (card.ability.extra.three) + 1
                    return true
                end,
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.four = (card.ability.extra.four) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                        }
                }
            end
        end
    end
}
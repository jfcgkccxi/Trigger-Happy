SMODS.Joker{ --+2
    key = "_2",
    config = {
        extra = {
            bonus = 0,
            hand_size = 2
        }
    },
    loc_txt = {
        ['name'] = '+2',
        ['text'] = {
            [1] = 'Scored {C:attention}Wild{} Cards',
            [2] = 'give {C:attention}+2 Hand Size {}',
            [3] = 'this round',
            [4] = '(Currently +#1#)'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.bonus}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                card.ability.extra.bonus = (card.ability.extra.bonus) + 2
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size)
                return true
            end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.bonus or 0) > 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.bonus).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.bonus)
                return true
            end
                }
            end
        end
        if context.selling_self  and not context.blueprint then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.bonus).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.bonus)
                return true
            end
                }
        end
        if context.starting_shop  then
                return {
                    func = function()
                    card.ability.extra.bonus = 0
                    return true
                end
                }
        end
    end
}
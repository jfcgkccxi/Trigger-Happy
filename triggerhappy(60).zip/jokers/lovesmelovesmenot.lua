SMODS.Joker{ --Loves Me, Loves Me Not
    key = "lovesmelovesmenot",
    config = {
        extra = {
            loveme = 0,
            counter = 10,
            set_probability = 0,
            mod_probability = 2,
            numerator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Loves Me, Loves Me Not',
        ['text'] = {
            [1] = 'Alternates between',
            [2] = '{C:blue}doubling{} and {C:red}nullifying{} {C:green}chances{}.',
            [3] = '({C:inactive}#2# Hands remaining{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.loveme, card.ability.extra.counter}}
    end,

    calculate = function(self, card, context)
        if context.fix_probability and not context.blueprint then
        local numerator, denominator = context.numerator, context.denominator
            if (card.ability.extra.loveme or 0) == 0 then
                numerator = card.ability.extra.set_probability
            end
      return {
        numerator = numerator, 
        denominator = denominator
      }
        end
          if context.mod_probability and not context.blueprint then
          local numerator, denominator = context.numerator, context.denominator
              if (card.ability.extra.loveme or 0) == 1 then
                  numerator = numerator * card.ability.extra.mod_probability
              end
        return {
          numerator = numerator, 
          denominator = denominator
        }
          end
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if (card.ability.extra.loveme or 0) >= 1 then
                card.ability.extra.loveme = 0
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                return {
                    message = "Loves me not..."
                }
            else
                card.ability.extra.loveme = (card.ability.extra.loveme) + 1
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                return {
                    message = "Loves me!"
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.counter or 0) == 0 then
                return {
                    func = function()
                card:undefined()
                return true
            end
                }
            end
        end
        if context.hand_drawn  and not context.blueprint then
            if (card.ability.extra.counter or 0) == 0 then
                return {
                    func = function()
                card:undefined()
                return true
            end
                }
            end
        end
    end
}
SMODS.Joker{ --Sierpinski
    key = "sierpinski",
    config = {
        extra = {
            three = 3
        }
    },
    loc_txt = {
        ['name'] = 'Sierpinski',
        ['text'] = {
            [1] = '{C:attention}3{}\'s score {C:blue}+#1# Chips{}',
            [2] = '{C:blue}+3{} for each hand containing',
            [3] = '{C:attention}Three of a Kind {}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.three}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if next(context.poker_hands["Three of a Kind"]) then
                card.ability.extra.three = (card.ability.extra.three) + 3
                return {
                    message = "+3"
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 3 then
                return {
                    chips = card.ability.extra.three
                }
            end
        end
    end
}
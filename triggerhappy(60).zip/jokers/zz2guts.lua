SMODS.Joker{ --Guts
    key = "zz2guts",
    config = {
        extra = {
            guts = 3,
            hands = 1,
            hand_size = 2
        }
    },
    loc_txt = {
        ['name'] = 'Guts',
        ['text'] = {
            [1] = '{C:spades}Defies Death{}.',
            [2] = '{C:red}-2 Hand Size{} and gains',
            [3] = '{X:red,C:white}X3{} each defiance.',
            [4] = '(Currently {X:red,C:white}X#1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 4,
        y = 3
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.guts}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.current_round.hands_left == 0 and G.GAME.chips / G.GAME.blind.chips < to_big(1)) then
                card.ability.extra.guts = (card.ability.extra.guts) + 3
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.hands
        ease_hands_played(card.ability.extra.hands)
        
                return true
            end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.hand_size)
                return true
            end,
                        colour = G.C.BLUE,
                        extra = {
                            Xmult = card.ability.extra.guts
                        }
                        }
                }
            end
        end
    end
}
SMODS.Joker{ --Solitaire
    key = "solitaire",
    config = {
        extra = {
            solitaireboost = 0,
            solitarecycle = 14
        }
    },
    loc_txt = {
        ['name'] = 'Solitaire',
        ['text'] = {
            [1] = 'Scoring {C:attention}Ranks {}in',
            [2] = '{C:attention}sequential {}order',
            [3] = 'gains {C:red}+1{} Mult',
            [4] = '(Currently {C:red}+#1#{},',
            [5] = 'Rank {C:green}#2#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.solitaireboost, card.ability.extra.solitarecycle}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.solitairevariable_card = { rank = 'Ace', id = 14 }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if (context.other_card:get_id() == 14 and (card.ability.extra.solitarecycle or 0) == 14) then
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                G.GAME.current_round.solitairevariable_card.rank = 'K'
                    G.GAME.current_round.solitairevariable_card.id = 13
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 13 and (card.ability.extra.solitarecycle or 0) == 13) then
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                G.GAME.current_round.solitairevariable_card.rank = 'Q'
                    G.GAME.current_round.solitairevariable_card.id = 12
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 12 and (card.ability.extra.solitarecycle or 0) == 12) then
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                G.GAME.current_round.solitairevariable_card.rank = 'J'
                    G.GAME.current_round.solitairevariable_card.id = 11
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 11 and (card.ability.extra.solitarecycle or 0) == 11) then
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                G.GAME.current_round.solitairevariable_card.rank = '10'
                    G.GAME.current_round.solitairevariable_card.id = 10
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 10 and (card.ability.extra.solitarecycle or 0) == 10) then
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                G.GAME.current_round.solitairevariable_card.rank = '9'
                    G.GAME.current_round.solitairevariable_card.id = 9
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 9 and (card.ability.extra.solitarecycle or 0) == 9) then
                G.GAME.current_round.solitairevariable_card.rank = '8'
                    G.GAME.current_round.solitairevariable_card.id = 8
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.solitarecycle or 0) == 8) then
                G.GAME.current_round.solitairevariable_card.rank = '7'
                    G.GAME.current_round.solitairevariable_card.id = 7
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 7 and (card.ability.extra.solitarecycle or 0) == 7) then
                G.GAME.current_round.solitairevariable_card.rank = '6'
                    G.GAME.current_round.solitairevariable_card.id = 6
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 6 and (card.ability.extra.solitarecycle or 0) == 6) then
                G.GAME.current_round.solitairevariable_card.rank = '5'
                    G.GAME.current_round.solitairevariable_card.id = 5
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 5 and (card.ability.extra.solitarecycle or 0) == 5) then
                G.GAME.current_round.solitairevariable_card.rank = '4'
                    G.GAME.current_round.solitairevariable_card.id = 4
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 4 and (card.ability.extra.solitarecycle or 0) == 4) then
                G.GAME.current_round.solitairevariable_card.rank = '3'
                    G.GAME.current_round.solitairevariable_card.id = 3
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 3 and (card.ability.extra.solitarecycle or 0) == 3) then
                G.GAME.current_round.solitairevariable_card.rank = '2'
                    G.GAME.current_round.solitairevariable_card.id = 2
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = math.max(0, (card.ability.extra.solitarecycle) - 1)
                return {
                    message = "+1"
                }
            elseif (context.other_card:get_id() == 2 and (card.ability.extra.solitarecycle or 0) == 2) then
                G.GAME.current_round.solitairevariable_card.rank = 'A'
                    G.GAME.current_round.solitairevariable_card.id = 14
                card.ability.extra.solitaireboost = (card.ability.extra.solitaireboost) + 1
                card.ability.extra.solitarecycle = 14
                return {
                    message = "+1"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.solitaireboost
                }
        end
    end
}
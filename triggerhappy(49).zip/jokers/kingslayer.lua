SMODS.Joker{ --Kingslayer
    key = "kingslayer",
    config = {
        extra = {
            timer = 4,
            Xmult = 3,
            hands = 1,
            Xmult2 = 3,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Kingslayer',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} every {C:blue}4th hand{}.',
            [2] = 'Hands containing a {C:attention}King{} extend',
            [3] = 'the window with {C:blue}+1 Hand{}.',
            [4] = '({C:inactive}#1# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.timer}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if (card.ability.extra.timer or 0) == 2 then
                card.ability.extra.timer = math.max(0, (card.ability.extra.timer) - 1)
                return {
                    message = "KILL"
                }
            elseif ((card.ability.extra.timer or 0) == 1 and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 13 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end,
                        colour = G.C.GREEN
                        }
                }
            elseif (card.ability.extra.timer or 0) == 1 then
                card.ability.extra.timer = 4
                return {
                    Xmult = card.ability.extra.Xmult2
                }
            else
                card.ability.extra.timer = math.max(0, (card.ability.extra.timer) - 1)
            end
        end
    end
}
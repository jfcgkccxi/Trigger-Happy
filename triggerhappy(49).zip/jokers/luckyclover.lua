SMODS.Joker{ --Lucky Clover
    key = "luckyclover",
    config = {
        extra = {
            clover = 0,
            cloverturn = 0,
            easteregg = 5,
            cloversuck = 0,
            anteactive = 1,
            odds = 6,
            numerator = 0,
            denominator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Lucky Clover',
        ['text'] = {
            [1] = 'Playing 3 {C:attention}Lucky{} cards',
            [2] = '{C:red}removes {}enhancement and',
            [3] = 'increases {C:green}probability {}',
            [4] = 'numerator and denominator by 1.',
            [5] = '(Ex. {C:green}1 in 2{} = {C:green}2 in 3{})',
            [6] = '{C:inactive}{s:0.9}({C:inactive}Once per Ante{}){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
          if context.mod_probability  then
          local numerator, denominator = context.numerator, context.denominator
                  numerator = numerator + card.ability.extra.clover
                denominator = denominator + card.ability.extra.clover
        return {
          numerator = numerator, 
          denominator = denominator
        }
          end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 4 and context.other_card:is_suit("Clubs")) then
                if SMODS.pseudorandom_probability(card, 'group_0_b1b17701', 1, card.ability.extra.odds, 'j_triggerh_luckyclover', false) then
              context.other_card:set_ability(G.P_CENTERS.m_lucky)
                        card.ability.extra.easteregg = (card.ability.extra.easteregg) + 3
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Lucky!", colour = G.C.BLUE})
          end
            elseif (SMODS.get_enhancements(context.other_card)["m_lucky"] == true and (card.ability.extra.cloversuck or 0) >= 1) then
                context.other_card:set_ability(G.P_CENTERS.c_base)
                return {
                    message = "Card Modified!"
                }
            end
        end
        if context.before and context.cardarea == G.jokers  then
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_lucky"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)() and (card.ability.extra.anteactive or 0) == 1) then
                return {
                    func = function()
                    card.ability.extra.clover = (card.ability.extra.clover) + 1
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.cloversuck = (card.ability.extra.cloversuck) + 1
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.anteactive = math.max(0, (card.ability.extra.anteactive) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.cloversuck = 0
                    return true
                end
                }
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            if (card.ability.extra.anteactive or 0) == 0 then
                return {
                    func = function()
                    card.ability.extra.anteactive = 1
                    return true
                end,
                    message = "Ready!"
                }
            end
        end
    end
}
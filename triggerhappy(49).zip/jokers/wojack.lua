SMODS.Joker{ --Wo-Jack
    key = "wojack",
    config = {
        extra = {
            pseudorandom = 1,
            repetitions = 1,
            dollars = 3,
            Tarot = 0,
            Planet = 0
        }
    },
    loc_txt = {
        ['name'] = 'Wo-Jack',
        ['text'] = {
            [1] = 'Played {C:attention}Jacks {}apply a',
            [2] = '{C:attention}Seal{} based on suit'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play and not context.blueprint then
            if (SMODS.get_enhancements(context.other_card)["m_wild"] == true and context.other_card:get_id() == 11) then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if (SMODS.get_enhancements(context.other_card)["m_wild"] == true and context.other_card:get_id() == 11) then
                local random_seal = SMODS.poll_seal({mod = 10})
                if random_seal then
                    context.other_card:set_seal(random_seal, true)
                end
                return {
                    message = "Sealed!",
                    extra = {
                        dollars = card.ability.extra.dollars,
                        colour = G.C.MONEY
                        }
                }
            elseif (context.other_card:is_suit("Hearts") and context.other_card:get_id() == 11) then
                context.other_card:set_seal("Red", true)
                return {
                    message = "Sealed!"
                }
            elseif (context.other_card:is_suit("Diamonds") and context.other_card:get_id() == 11) then
                context.other_card:set_seal("Gold", true)
                return {
                    message = "Sealed!"
                }
            elseif (context.other_card:is_suit("Clubs") and context.other_card:get_id() == 11) then
                context.other_card:set_seal("Blue", true)
                return {
                    message = "Sealed!"
                }
            elseif (context.other_card:is_suit("Spades") and context.other_card:get_id() == 11) then
                context.other_card:set_seal("Purple", true)
                return {
                    message = "Sealed!"
                }
            end
        end
        if context.discard  and not context.blueprint then
            if ((function()
    local rankFound = false
    for i, c in ipairs(context.full_hand) do
        if c:get_id() == 11 then
            rankFound = true
            break
        end
    end
    
    return rankFound
end)() and SMODS.get_enhancements(context.other_card)["m_wild"] == true) then
                return {
                    func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', key = nil, key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                    end
                    return true
                end
                }
            end
        end
        if context.cardarea == G.hand and context.end_of_round  and not context.blueprint then
            if (context.other_card:get_id() == 11 and SMODS.get_enhancements(context.other_card)["m_wild"] == true) then
                return {
                    func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Planet', key = nil, key_append = 'joker_forge_planet'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_planet'), colour = G.C.SECONDARY_SET.Planet})
                    end
                    return true
                end
                }
            end
        end
    end
}
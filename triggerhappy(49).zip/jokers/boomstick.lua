SMODS.Joker{ --Boomstick
    key = "boomstick",
    config = {
        extra = {
            shotgunmult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Boomstick',
        ['text'] = {
            [1] = 'Discarding {C:attention}Steel{}',
            [2] = 'cards adds {X:red,C:white}X1.5{}.',
            [3] = 'Resets upon playing hand.',
            [4] = '(Currently {X:red,C:white}X#1#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.shotgunmult}}
    end,

    calculate = function(self, card, context)
        if context.discard  and not context.blueprint then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    func = function()
                    card.ability.extra.shotgunmult = (card.ability.extra.shotgunmult) + 1.5
                    return true
                end,
                    message = "Click!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if card.ability.extra.shotgunmult > 1 then
                local shotgunmult_value = card.ability.extra.shotgunmult
                card.ability.extra.shotgunmult = 0
                return {
                    Xmult = shotgunmult_value
                }
            end
        end
    end
}
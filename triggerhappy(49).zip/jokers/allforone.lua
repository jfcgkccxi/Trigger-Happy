SMODS.Joker{ --All For One
    key = "allforone",
    config = {
        extra = {
            allforone = 0,
            retr = 0
        }
    },
    loc_txt = {
        ['name'] = 'All For One',
        ['text'] = {
            [1] = 'Scored {C:attention}Aces{} increase {C:attention}',
            [2] = 'retriggers {}for the',
            [3] = 'next {C:attention}High Card{}.',
            [4] = '({C:inactive}Currently #2#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.allforone, card.ability.extra.retr}}
    end,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if ((card.ability.extra.allforone or 0) == 1 and context.scoring_name == "High Card") then
                return {
                    repetitions = card.ability.extra.retr,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if ((card.ability.extra.allforone or 0) == 0 and context.other_card:get_id() == 14) then
                card.ability.extra.retr = (card.ability.extra.retr) + 1
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if ((card.ability.extra.allforone or 0) == 0 and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 14 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                card.ability.extra.allforone = 1
            elseif ((card.ability.extra.allforone or 0) == 1 and context.scoring_name == "High Card") then
                card.ability.extra.allforone = 0
                card.ability.extra.retr = 0
            end
        end
    end
}
SMODS.Joker{ --The Jerker
    key = "thejerker",
    config = {
        extra = {
            jerker = 0
        }
    },
    loc_txt = {
        ['name'] = 'The Jerker',
        ['text'] = {
            [1] = 'Scoring a single {C:attention}Jack',
            [2] = '{}increases {C:attention}retriggers {}by 1.',
            [3] = 'Resets at end of round.',
            [4] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = card.ability.extra.jerker,
                    message = localize('k_again_ex')
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.jerker = 0
                    return true
                end,
                    message = "Reset!"
                }
        end
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if (next(context.poker_hands["High Card"]) and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 11 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount == 1
end)()) then
                card.ability.extra.jerker = (card.ability.extra.jerker) + 1
            end
        end
    end
}
SMODS.Joker{ --Ace in The Hole
    key = "aceinthehole",
    config = {
        extra = {
            counter = 10,
            pb_x_mult_aa7a6e6d = 0.1,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Ace in The Hole',
        ['text'] = {
            [1] = 'Scored {C:attention}Aces {}gain a permanent {X:red,C:white}X0.1{}',
            [2] = '({C:inactive}#1# uses remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.counter}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if (context.other_card:get_id() == 14 and (card.ability.extra.counter or 0) >= 1) then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_aa7a6e6d
                card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                return {
                    extra = { message = "+0.1", colour = G.C.MULT }, card = card
                }
            end
        end
        if context.hand_drawn  and not context.blueprint then
            if (card.ability.extra.counter or 0) <= 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.counter or 0) <= 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}
SMODS.Joker{ --Warped Door
    key = "warpeddoor",
    config = {
        extra = {
            active = 1,
            ethereal = 0
        }
    },
    loc_txt = {
        ['name'] = 'Warped Door',
        ['text'] = {
            [1] = 'Playing a hand with a {C:attention}7{} and',
            [2] = 'a {C:attention}random{} rank creates an',
            [3] = '{C:spectral}Ethereal {}tag'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    set_ability = function(self, card, initial)
        G.GAME.current_round.suit_card = { suit = 'Spades' }
        G.GAME.current_round.rank_card = { rank = 'Ace', id = 14 }
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 7 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == G.GAME.current_round.rank_card.id then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_ethereal")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                return {
                    message = "Created Tag!"
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                if G.playing_cards then
                        local valid_rank_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank_cards[#valid_rank_cards + 1] = v
                            end
                        end
                        if valid_rank_cards[1] then
                            local rank_card = pseudorandom_element(valid_rank_cards, pseudoseed('rank' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank_card.rank = rank_card.base.value
                            G.GAME.current_round.rank_card.id = rank_card.base.id
                        end
                    end
                return {
                    message = "Switch!"
                }
        end
    end
}
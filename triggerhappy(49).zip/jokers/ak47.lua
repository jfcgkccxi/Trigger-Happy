SMODS.Joker{ --AK-47
    key = "ak47",
    config = {
        extra = {
            repetitions = 3,
            repetitions2 = 3
        }
    },
    loc_txt = {
        ['name'] = 'AK-47',
        ['text'] = {
            [1] = '{C:attention}Retriggers{} scored',
            [2] = '4\'s and 7\'s {C:attention}3{} times,',
            [3] = '{C:red}destroying {}them.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:get_id() == 4 then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            elseif context.other_card:get_id() == 7 then
                return {
                    repetitions = card.ability.extra.repetitions2,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card:get_id() == 4 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            elseif context.other_card:get_id() == 7 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            end
        end
    end
}
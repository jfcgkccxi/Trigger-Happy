SMODS.Joker{ --Planet Buster
    key = "planetbuster",
    config = {
        extra = {
            pluto = 0,
            mercury = 0,
            venus = 0,
            uranus = 0,
            earth = 0,
            jupiter = 0,
            saturn = 0,
            neptune = 0,
            mars = 0,
            ceres = 0,
            eris = 0,
            planetx = 0
        }
    },
    loc_txt = {
        ['name'] = 'Planet Buster',
        ['text'] = {
            [1] = '{C:planet}Planet{} cards',
            [2] = 'increase {C:attention}retriggers {}',
            [3] = 'for their given hand.',
            [4] = '{C:attention}Resets {}at end of round.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_pluto' then
                return {
                    func = function()
                    card.ability.extra.pluto = (card.ability.extra.pluto) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_mercury' then
                return {
                    func = function()
                    card.ability.extra.mercury = (card.ability.extra.mercury) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_uranus' then
                return {
                    func = function()
                    card.ability.extra.uranus = (card.ability.extra.uranus) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_venus' then
                return {
                    func = function()
                    card.ability.extra.venus = (card.ability.extra.venus) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_saturn' then
                return {
                    func = function()
                    card.ability.extra.saturn = (card.ability.extra.saturn) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_jupiter' then
                return {
                    func = function()
                    card.ability.extra.jupiter = (card.ability.extra.jupiter) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_earth' then
                return {
                    func = function()
                    card.ability.extra.earth = (card.ability.extra.earth) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_mars' then
                return {
                    func = function()
                    card.ability.extra.mars = (card.ability.extra.mars) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_neptune' then
                return {
                    func = function()
                    card.ability.extra.neptune = (card.ability.extra.neptune) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_planet_x' then
                return {
                    func = function()
                    card.ability.extra.planetx = (card.ability.extra.planetx) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_ceres' then
                return {
                    func = function()
                    card.ability.extra.ceres = (card.ability.extra.ceres) + 1
                    return true
                end
                }
            elseif context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_eris' then
                return {
                    func = function()
                    card.ability.extra.eris = (card.ability.extra.eris) + 1
                    return true
                end
                }
            end
        end
        if context.repetition and context.cardarea == G.play  then
            if context.scoring_name == "High Card" then
                return {
                    repetitions = card.ability.extra.pluto,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Pair" then
                return {
                    repetitions = card.ability.extra.mercury,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Two Pair" then
                return {
                    repetitions = card.ability.extra.uranus,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Three of a Kind" then
                return {
                    repetitions = card.ability.extra.venus,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Straight" then
                return {
                    repetitions = card.ability.extra.saturn,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Flush" then
                return {
                    repetitions = card.ability.extra.jupiter,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Full House" then
                return {
                    repetitions = card.ability.extra.earth,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Four of a Kind" then
                return {
                    repetitions = card.ability.extra.mars,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Straight Flush" then
                return {
                    repetitions = card.ability.extra.neptune,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Five of a Kind" then
                return {
                    repetitions = card.ability.extra.planetx,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Flush Five" then
                return {
                    repetitions = card.ability.extra.eris,
                    message = localize('k_again_ex')
                }
            elseif context.scoring_name == "Flush House" then
                return {
                    repetitions = card.ability.extra.ceres,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                local neptune_value = card.ability.extra.neptune
                return {
                    func = function()
                    card.ability.extra.pluto = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.mercury = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.uranus = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.venus = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.earth = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.jupiter = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.saturn = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.neptune = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.neptune = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.mars = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.ceres = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.planetx = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.eris = 0
                    return true
                end,
                            colour = G.C.BLUE,
                        extra = {
                            message = "Reset!",
                            colour = G.C.ORANGE
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                }
        end
    end
}
SMODS.Joker{ --Crazy Eights
    key = "crazyeights",
    config = {
        extra = {
            range = 1
        }
    },
    loc_txt = {
        ['name'] = 'Crazy Eights',
        ['text'] = {
            [1] = '{C:attention}Randomizes {}the',
            [2] = 'Enhancements of',
            [3] = 'scored {C:attention}8{}\'s'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 1) then
                context.other_card:set_ability(G.P_CENTERS.m_gold)
                card.ability.extra.range = pseudorandom('range_7ee2d536', 1, 7)
                return {
                    message = "Card Modified!"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 2) then
                context.other_card:set_ability(G.P_CENTERS.m_bonus)
                card.ability.extra.range = pseudorandom('range_dc9ab8f7', 1, 7)
                return {
                    message = "Card Modified!"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 3) then
                context.other_card:set_ability(G.P_CENTERS.m_lucky)
                card.ability.extra.range = pseudorandom('range_3b57e433', 1, 7)
                return {
                    message = "Card Modified!"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 4) then
                context.other_card:set_ability(G.P_CENTERS.m_mult)
                card.ability.extra.range = pseudorandom('range_d55805cc', 1, 7)
                return {
                    message = "Card Modified!"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 5) then
                context.other_card:set_ability(G.P_CENTERS.m_wild)
                card.ability.extra.range = pseudorandom('range_35fa9673', 1, 7)
                return {
                    message = "Card Modified!"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 6) then
                context.other_card:set_ability(G.P_CENTERS.m_glass)
                card.ability.extra.range = pseudorandom('range_57aeb293', 1, 7)
                return {
                    message = "Card Modified!"
                }
            elseif (context.other_card:get_id() == 8 and (card.ability.extra.range or 0) == 7) then
                context.other_card:set_ability(G.P_CENTERS.m_steel)
                card.ability.extra.range = pseudorandom('range_5eb78fc5', 1, 7)
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}
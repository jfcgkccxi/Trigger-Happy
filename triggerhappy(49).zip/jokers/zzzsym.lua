SMODS.Joker{ --Sym
    key = "zzzsym",
    config = {
        extra = {
            pseudorandom = 1,
            literallynothinglol = 0,
            repetitions_min = 1,
            repetitions_max = 3,
            odds = 8
        }
    },
    loc_txt = {
        ['name'] = 'Sym',
        ['text'] = {
            [1] = 'Each card scored',
            [2] = '{C:attention}retriggers {}1-3 times,',
            [3] = '{C:green}#3# in #4#{} chance to',
            [4] = '{C:red}destroy {}triggered cards',
            [5] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 8,
        y = 6
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_triggerh_zzzsym') 
        return {vars = {card.ability.extra.pseudorandom, card.ability.extra.literallynothinglol, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = pseudorandom('repetitions_8f927346', card.ability.extra.repetitions_min, card.ability.extra.repetitions_max),
                    message = localize('k_again_ex')
                }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_3862d5ae', 1, card.ability.extra.odds, 'j_triggerh_zzzsym', false) then
              context.other_card.should_destroy = true
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
          end
            end
        end
    end
}
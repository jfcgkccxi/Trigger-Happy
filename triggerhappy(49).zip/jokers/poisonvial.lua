SMODS.Joker{ --Poison Vial
    key = "poisonvial",
    config = {
        extra = {
            poisonboost = 1,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Poison Vial',
        ['text'] = {
            [1] = 'Adds {C:red}+#1#{} Mult to scored Queens',
            [2] = 'Mult increases by {C:attention}+1{} when a',
            [3] = 'Queen is {C:red}destroyed{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.poisonboost}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 12 then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.poisonboost
                return {
                    extra = { message = "+1", colour = G.C.MULT }, card = card
                }
            end
        end
        if context.remove_playing_cards  and not context.blueprint then
            if (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 12 then
            return true
        end
    end
    return false
end)() then
                return {
                    func = function()
                    card.ability.extra.poisonboost = (card.ability.extra.poisonboost) + 1
                    return true
                end,
                    message = "Poison Up!"
                }
            end
        end
    end
}
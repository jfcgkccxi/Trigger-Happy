SMODS.Joker{ --Blood Garden
    key = "bloodgarden",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Blood Garden',
        ['text'] = {
            [1] = '{C:hearts}Hearts{} held in hand stack {X:red,C:white}X0.1{}',
            [2] = '(Caps at {X:red,C:white}X2.0{})',
            [3] = '{C:clubs}Clubs{} held in hand score {X:red,C:white}X#1#{},',
            [4] = 'consuming {X:red,C:white}0.1X{} stack'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                local xmult_value = card.ability.extra.xmult
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.1
                    return true
                end,
                    message = "+0.1",
                    extra = {
                        Xmult = xmult_value,
                        extra = {
                            func = function()
                    card.ability.extra.xmult = math.max(0, (card.ability.extra.xmult) - 0.1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.other_card:is_suit("Clubs") and (card.ability.extra.xmult or 0) > 1) then
                local xmult_value = card.ability.extra.xmult
                return {
                    Xmult = xmult_value,
                    extra = {
                        func = function()
                    card.ability.extra.xmult = math.max(0, (card.ability.extra.xmult) - 0.1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.other_card:is_suit("Hearts") and (card.ability.extra.xmult or 0) < 2) then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.1
                    return true
                end,
                    message = "+0.1"
                }
            end
        end
    end
}
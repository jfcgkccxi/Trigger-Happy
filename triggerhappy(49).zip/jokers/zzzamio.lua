SMODS.Joker{ --Amio
    key = "zzzamio",
    config = {
        extra = {
            xchips = 1
        }
    },
    loc_txt = {
        ['name'] = 'Amio',
        ['text'] = {
            [1] = '{C:clubs}Clubs{} held in hand stack {X:blue,C:white}X0.1{}',
            [2] = '{C:money}Diamonds{} score {X:blue,C:white}X#1#{},',
            [3] = 'consuming {X:blue,C:white}X0.2{} stack'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 7,
        y = 0
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xchips}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:is_suit("Clubs") then
                return {
                    func = function()
                    card.ability.extra.xchips = (card.ability.extra.xchips) + 0.1
                    return true
                end,
                    message = "+0.1"
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if ((card.ability.extra.xchips or 0) > 1 and context.other_card:is_suit("Diamonds")) then
                local xchips_value = card.ability.extra.xchips
                card.ability.extra.xchips = math.max(0, (card.ability.extra.xchips) - 0.2)
                return {
                    x_chips = xchips_value
                }
            end
        end
    end
}
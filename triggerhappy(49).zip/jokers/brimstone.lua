SMODS.Joker{ --Brimstone
    key = "brimstone",
    config = {
        extra = {
            inferno = 0,
            Xmult = 6
        }
    },
    loc_txt = {
        ['name'] = 'Brimstone',
        ['text'] = {
            [1] = 'Scoring three {C:red}6{}s',
            [2] = '{C:red}destroys {}all cards in hand',
            [3] = 'and scores {X:red,C:white}X6{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 6 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() then
                card.ability.extra.inferno = 1
            end
        end
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            context.other_card.should_destroy = false
            if (card.ability.extra.inferno or 0) == 1 then
                context.other_card.should_destroy = true
                return {
                    message = " "
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.inferno = 0
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.inferno or 0) == 1 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}
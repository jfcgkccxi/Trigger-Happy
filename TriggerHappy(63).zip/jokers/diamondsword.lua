SMODS.Joker{ --Diamond Sword
    key = "diamondsword",
    config = {
        extra = {
            sharpness = 1,
            looting = 0,
            knockback = 0,
            sweepingedge = 0,
            smite = 0,
            bane = 0,
            fireaspect = 0,
            sweepingedgecounter = 0,
            sweepingedgesubtraction = 0,
            counter = 8,
            breach = 1,
            unbreakingcounter = 0,
            unbreaking = 0,
            unbreakingpieces = 0,
            knockbackcounter = 0,
            phantomstrike = 0,
            phantomstrikepart = 0,
            knockbackperround = 0,
            hand_size = 1,
            hands = 1,
            discards = 1,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Diamond Sword',
        ['text'] = {
            [1] = 'Stacks up to {C:attention}#10#{} Enchantments',
            [2] = 'with certain {C:planet}Planet{} cards.',
            [3] = '',
            [4] = 'Pluto - {C:red}+4{} Mult scoring {C:attention}Aces{} ({C:red}+#6#{})',
            [5] = 'Mercury - {C:blue}+30{} Chips ({C:blue}+#5#{})',
            [6] = 'Venus - {C:red}+20{} Mult ({C:red}+#7#{})',
            [7] = 'Uranus - {C:red}+1/2 Discard{} ({C:red}#15#/2{})',
            [8] = 'Earth - {C:blue}+1/3 Hands{} ({C:blue}#12#/3{})',
            [9] = 'Jupiter - {C:money}$2 {}Per Round ({C:money}$#2#{})',
            [10] = 'Saturn - {C:attention}+1/2 Hand Size{} ({C:attention}#8#/2{})',
            [11] = 'Mars - {X:red,C:white}X0.5{} Mult ({X:red,C:white}X#1#{})',
            [12] = 'Neptune - {X:blue,C:white}X0.5{} Chips ({X:blue,C:white}X#11#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.sharpness, card.ability.extra.looting, card.ability.extra.knockback, card.ability.extra.sweepingedge, card.ability.extra.smite, card.ability.extra.bane, card.ability.extra.fireaspect, card.ability.extra.sweepingedgecounter, card.ability.extra.sweepingedgesubtraction, card.ability.extra.counter, card.ability.extra.breach, card.ability.extra.unbreakingcounter, card.ability.extra.unbreaking, card.ability.extra.unbreakingpieces, card.ability.extra.knockbackcounter}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  and not context.blueprint then
            if (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_jupiter' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.looting = (card.ability.extra.looting) + 2
                    return true
                end,
                    message = "Looting!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_mercury' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.smite = (card.ability.extra.smite) + 30
                    return true
                end,
                    message = "Smite!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_pluto' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.bane = (card.ability.extra.bane) + 4
                    return true
                end,
                    message = "Bane!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_venus' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.fireaspect = (card.ability.extra.fireaspect) + 20
                    return true
                end,
                    message = "Fire Aspect!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_saturn' and (card.ability.extra.sweepingedge or 0) == 0.5 and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size)
                return true
            end,
                    extra = {
                        func = function()
                    card.ability.extra.sweepingedge = 0
                    return true
                end,
                            message = "Sweeping Edge!",
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.sweepingedgecounter = (card.ability.extra.sweepingedgecounter) + 1
                    return true
                end,
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.sweepingedgesubtraction = (card.ability.extra.sweepingedgesubtraction) + 1
                    return true
                end,
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_mars' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.sharpness = (card.ability.extra.sharpness) + 0.5
                    return true
                end,
                    message = "Sharpness!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_neptune' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.breach = (card.ability.extra.breach) + 0.5
                    return true
                end,
                    message = "Breach!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_earth' and (card.ability.extra.counter or 0) > 0 and (card.ability.extra.unbreakingpieces or 0) == 0.6) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end,
                    extra = {
                        func = function()
                    card.ability.extra.unbreakingpieces = 0
                    return true
                end,
                            message = "Unbreaking!",
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.unbreakingcounter = (card.ability.extra.unbreakingcounter) + 1
                    return true
                end,
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED,
                        extra = {
                            func = function()
                    card.ability.extra.unbreaking = (card.ability.extra.unbreaking) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_saturn' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.sweepingedge = (card.ability.extra.sweepingedge) + 0.5
                    return true
                end,
                    message = "+1/2",
                    extra = {
                        func = function()
                    card.ability.extra.sweepingedgecounter = (card.ability.extra.sweepingedgecounter) + 1
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_earth' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.unbreakingpieces = (card.ability.extra.unbreakingpieces) + 0.3
                    return true
                end,
                    message = "+1/3",
                    extra = {
                        func = function()
                    card.ability.extra.unbreakingcounter = (card.ability.extra.unbreakingcounter) + 1
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_uranus' and (card.ability.extra.counter or 0) > 0 and (card.ability.extra.knockback or 0) == 0.5) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discards).." Discard", colour = G.C.ORANGE})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.discards
                return true
            end,
                    extra = {
                        func = function()
                    card.ability.extra.knockback = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.knockbackcounter = (card.ability.extra.knockbackcounter) + 1
                    return true
                end,
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.knockbackperround = (card.ability.extra.knockbackperround) + 1
                    return true
                end,
                            message = "Knockback!",
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_uranus' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.knockback = (card.ability.extra.knockback) + 0.5
                    return true
                end,
                    message = "+1/2",
                    extra = {
                        func = function()
                    card.ability.extra.knockbackcounter = (card.ability.extra.knockbackcounter) + 1
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_eris' and (card.ability.extra.phantomstrikepart or 0) > 0.5) then
                return {
                    func = function()
                    card.ability.extra.phantomstrikepart = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.phantomstrike = (card.ability.extra.phantomstrike) + 1
                    return true
                end,
                            message = "Phantom Strike!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_ceres' and (card.ability.extra.phantomstrikepart or 0) > 0.5) then
                return {
                    func = function()
                    card.ability.extra.phantomstrikepart = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.phantomstrike = (card.ability.extra.phantomstrike) + 1
                    return true
                end,
                            message = "Phantom Strike!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_planet_x' and (card.ability.extra.phantomstrikepart or 0) > 0.5) then
                return {
                    func = function()
                    card.ability.extra.phantomstrikepart = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.phantomstrike = (card.ability.extra.phantomstrike) + 1
                    return true
                end,
                            message = "Phantom Strike!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                            colour = G.C.RED
                        }
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_planet_x' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.phantomstrikepart = (card.ability.extra.phantomstrikepart) + 0.25
                    return true
                end,
                    message = "+1/4",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_ceres' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.phantomstrikepart = (card.ability.extra.phantomstrikepart) + 0.25
                    return true
                end,
                    message = "+1/4",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Planet' and context.consumeable.config.center.key == 'c_eris' and (card.ability.extra.counter or 0) > 0) then
                return {
                    func = function()
                    card.ability.extra.phantomstrikepart = (card.ability.extra.phantomstrikepart) + 0.25
                    return true
                end,
                    message = "+1/4",
                    extra = {
                        func = function()
                    card.ability.extra.counter = math.max(0, (card.ability.extra.counter) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.looting or 0) > 0 then
                return {
                    dollars = card.ability.extra.looting
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.smite,
                    extra = {
                        mult = card.ability.extra.fireaspect,
                        extra = {
                            Xmult = card.ability.extra.sharpness,
                        extra = {
                            x_chips = card.ability.extra.breach,
                            colour = G.C.DARK_EDITION
                        }
                        }
                        }
                }
        end
        if context.selling_self  and not context.blueprint then
            if (card.ability.extra.sweepingedgesubtraction or 0) > 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.sweepingedgesubtraction).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.sweepingedgesubtraction)
                return true
            end
                }
            end
        end
        if context.repetition and context.cardarea == G.play  then
            if (card.ability.extra.phantomstrike or 0) > 0 then
                return {
                    repetitions = card.ability.extra.phantomstrike,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 14 and (card.ability.extra.bane or 0) > 0) then
                return {
                    mult = card.ability.extra.bane
                }
            end
        end
        if context.setting_blind  then
            if (card.ability.extra.unbreaking or 0) > 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.unbreaking).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.unbreaking
                return true
            end
                }
            elseif (card.ability.extra.knockback or 0) > 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.knockbackperround).." Discard", colour = G.C.ORANGE})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.knockbackperround
                return true
            end
                }
            end
        end
    end
}
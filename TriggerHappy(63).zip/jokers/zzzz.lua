SMODS.Joker{ --©ðsžšåÞя½	ŠŘ§ŮÞ¥¿Þ¥¿舐
    key = "zzzz",
    config = {
        extra = {
            negatives = 0,
            odds = 12
        }
    },
    loc_txt = {
        ['name'] = '©ðsžšåÞя½	ŠŘ§ŮÞ¥¿Þ¥¿舐',
        ['text'] = {
            [1] = 'Card held in hand may become {C:dark_edition}Negative{}',
            [2] = 'Playing {C:attention}3{} {C:dark_edition}Negative {}cards {C:red}destroys {}them,',
            [3] = 'creating a {C:dark_edition}Negative {}Tag'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card.edition == nil then
                if SMODS.pseudorandom_probability(card, 'group_0_1a3883c7', 1, card.ability.extra.odds, 'j_triggerh_zzzz', false) then
              SMODS.calculate_effect({func = function()
                context.other_card:set_edition("e_negative", true)
                    end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            end
        end
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if playing_card.edition and playing_card.edition.key == "e_negative" then
            count = count + 1
        end
    end
    return count == 3
end)() and context.other_card.edition and context.other_card.edition.key == "e_negative") then
                context.other_card.should_destroy = true
                card.ability.extra.negatives = (card.ability.extra.negatives) + 1
                return {
                    message = "Destroyed!"
                }
            end
        end
        if context.before and context.cardarea == G.jokers  then
            if (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if playing_card.edition and playing_card.edition.key == "e_negative" then
            count = count + 1
        end
    end
    return count == 3
end)() then
                return {
                    func = function()
            G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_negative")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                    return true
                end,
                    message = "Created Tag!"
                }
            end
        end
    end
}
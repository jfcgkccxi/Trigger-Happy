SMODS.Joker{ --Blazing Umbra
    key = "blazingumbra",
    config = {
        extra = {
            mult = 1,
            counter = 0
        }
    },
    loc_txt = {
        ['name'] = 'Blazing Umbra',
        ['text'] = {
            [1] = 'Scored {C:spades}Spades{} stack {X:red,C:white}X0.1{}',
            [2] = '(Caps at {X:red,C:white}X2.0{})',
            [3] = '{C:money}Diamonds{} score {X:red,C:white}X#1#{},',
            [4] = 'consuming {X:red,C:white}X0.1{} stack'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.one_card = { suit = 'Spades' }
        G.GAME.current_round.two_card = { suit = 'Diamonds' }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                local mult_value = card.ability.extra.mult
                card.ability.extra.mult = (card.ability.extra.mult) + 0.1
                card.ability.extra.mult = math.max(0, (card.ability.extra.mult) - 0.1)
                return {
                    Xmult = mult_value
                }
            elseif (context.other_card:is_suit("Spades") and (card.ability.extra.mult or 0) < 2) then
                card.ability.extra.mult = (card.ability.extra.mult) + 0.1
                return {
                    message = "+0.1"
                }
            elseif (context.other_card:is_suit("Diamonds") and (card.ability.extra.mult or 0) > 1) then
                local mult_value = card.ability.extra.mult
                card.ability.extra.mult = math.max(0, (card.ability.extra.mult) - 0.1)
                return {
                    Xmult = mult_value
                }
            end
        end
    end
}
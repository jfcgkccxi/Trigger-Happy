SMODS.Joker{ --Red Queen
    key = "redqueen",
    config = {
        extra = {
            retrig = 1,
            retrigactive = 0
        }
    },
    loc_txt = {
        ['name'] = 'Red Queen',
        ['text'] = {
            [1] = 'Retriggers played {C:attention}Straights{}',
            [2] = '{C:attention}+1{} Retrigger this round',
            [3] = 'per Blind {C:attention}Skipped{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if next(context.poker_hands["Straight"]) then
                return {
                    func = function()
                    card.ability.extra.retrigactive = card.ability.extra.retrig
                    return true
                end
                }
            end
        end
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = card.ability.extra.retrigactive,
                    message = localize('k_again_ex')
                }
        end
        if context.skip_blind  then
                return {
                    func = function()
                    card.ability.extra.retrig = (card.ability.extra.retrig) + 1
                    return true
                end,
                    message = "Vroom!"
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.retrig = 1
                    return true
                end
                }
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.retrigactive = 0
                    return true
                end
                }
        end
    end
}
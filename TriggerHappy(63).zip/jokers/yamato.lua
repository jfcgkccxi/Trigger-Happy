SMODS.Joker{ --Yamato
    key = "yamato",
    config = {
        extra = {
            yamato = 0
        }
    },
    loc_txt = {
        ['name'] = 'Yamato',
        ['text'] = {
            [1] = 'Played {C:attention}Glass {}',
            [2] = 'cards {C:attention}retrigger {}',
            [3] = 'cards held in hand',
            [4] = '({C:inactive}Excluding Retriggers{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.hand and (next(context.card_effects[1]) or #context.card_effects > 1)  then
                return {
                    repetitions = card.ability.extra.yamato,
                    message = localize('k_again_ex')
                }
        end
        if context.hand_drawn  then
                return {
                    func = function()
                    card.ability.extra.yamato = 0
                    return true
                end
                }
        end
        if context.before and context.cardarea == G.jokers  then
            if (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 7
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 7
                    return true
                end
                }
            elseif (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 6
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 6
                    return true
                end
                }
            elseif (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 5
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 5
                    return true
                end
                }
            elseif (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 4
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 4
                    return true
                end
                }
            elseif (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 3
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 3
                    return true
                end
                }
            elseif (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 2
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 2
                    return true
                end
                }
            elseif (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count == 1
end)() then
                return {
                    func = function()
                    card.ability.extra.yamato = 1
                    return true
                end
                }
            end
        end
    end
}
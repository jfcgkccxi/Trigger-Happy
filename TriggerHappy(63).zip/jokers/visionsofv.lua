SMODS.Joker{ --Visions of V
    key = "visionsofv",
    config = {
        extra = {
            counter = 5,
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'Visions of V',
        ['text'] = {
            [1] = '{C:green}#2# in #3#{} chance to',
            [2] = 'self-destruct.',
            [3] = 'Triggers {C:attention}5{}s in hand.',
            [4] = 'Every {C:attention}5{}th {C:attention}5{} in hand',
            [5] = 'creates a {C:dark_edition}Negative {}card.',
            [6] = '({C:inactive}#1# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_triggerh_visionsofv') 
        return {vars = {card.ability.extra.counter, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:get_id() == 5 then
                return {
                    func = function()
                    card.ability.extra.counter = (card.ability.extra.counter) + -1
                    return true
                end,
                    message = "-1"
                }
            elseif (card.ability.extra.counter or 0) < 1 then
                local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.c_base
                }, G.discard, true, false, nil, true)
            new_card:set_edition("e_negative", true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function() 
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        return true
                    end
                }))
                return {
                    message = "Added Card to Hand!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = (card.ability.extra.counter) + 5
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.hand_drawn  then
            if (card.ability.extra.counter or 0) < 1 then
                return {
                    func = function()
                local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.c_base
                }, G.discard, true, false, nil, true)
            new_card:set_edition("e_negative", true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end,
                    message = "Added Card to Hand!",
                    extra = {
                        func = function()
                    card.ability.extra.counter = (card.ability.extra.counter) + 5
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_7cf97f1a', 1, card.ability.extra.odds, 'j_triggerh_visionsofv', false) then
              SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
          end
            end
        end
    end
}
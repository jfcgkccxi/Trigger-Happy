SMODS.Joker{ --Three Pointer
    key = "threepointer",
    config = {
        extra = {
            discardsss = 0,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Three Pointer',
        ['text'] = {
            [1] = 'Holding a {C:attention}3 {}in the {C:blue}Final {}{C:blue}Hand',
            [2] = '{}adds a {C:red}discard {}for',
            [3] = 'the next round',
            [4] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            if (card.ability.extra.discardsss or 0) > 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discardsss).." Discard", colour = G.C.ORANGE})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.discardsss
                return true
            end
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if (context.other_card:get_id() == 3 and G.GAME.current_round.hands_left == 1) then
                return {
                    func = function()
                    card.ability.extra.discardsss = (card.ability.extra.discardsss) + 1
                    return true
                end,
                    message = "+1"
                }
            end
        end
        if context.pre_discard  then
                return {
                    func = function()
                    card.ability.extra.discardsss = 0
                    return true
                end
                }
        end
    end
}
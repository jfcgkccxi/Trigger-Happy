SMODS.Joker{ --Real Knife
    key = "realknife",
    config = {
        extra = {
            glasscompensation = 0,
            die = 0,
            Xmult = 2,
            Xmult2 = 99999,
            Xmult3 = 99999,
            Xmult4 = 99999,
            Xmult5 = 99999,
            Xmult6 = 99999,
            Xmult7 = 99999,
            Xmult8 = 99999,
            Xmult9 = 99999,
            Xmult10 = 99999
        }
    },
    loc_txt = {
        ['name'] = 'Real Knife',
        ['text'] = {
            [1] = 'Scored {C:attention}9{}s turn',
            [2] = 'to {C:attention}Glass {}Cards'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if (context.other_card:get_id() == 9 and SMODS.get_enhancements(context.other_card)["m_glass"] == true) then
                card.ability.extra.glasscompensation = 1
            elseif context.other_card:get_id() == 9 then
                context.other_card:set_ability(G.P_CENTERS.m_glass)
                return {
                    message = "9",
                    extra = {
                        Xmult = card.ability.extra.Xmult
                        }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if (G.GAME.chips / G.GAME.blind.chips < to_big(0.25) and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 9 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() and (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)() and G.GAME.current_round.hands_left == 0) then
                card.ability.extra.die = 1
                return {
                    Xmult = card.ability.extra.Xmult2,
                    extra = {
                        Xmult = card.ability.extra.Xmult3,
                        extra = {
                            Xmult = card.ability.extra.Xmult4,
                        extra = {
                            Xmult = card.ability.extra.Xmult5,
                        extra = {
                            Xmult = card.ability.extra.Xmult6,
                        extra = {
                            Xmult = card.ability.extra.Xmult7,
                        extra = {
                            Xmult = card.ability.extra.Xmult8,
                        extra = {
                            Xmult = card.ability.extra.Xmult9,
                        extra = {
                            Xmult = card.ability.extra.Xmult10
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.die or 0) == 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}
SMODS.Joker{ --Fortune III
    key = "fortuneiii",
    config = {
        extra = {
            random = 1,
            odds = 5,
            odds2 = 5,
            odds3 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Fortune III',
        ['text'] = {
            [1] = '{C:attention}Stone{} cards have a {C:green}#1# in 5{}',
            [2] = 'chance to gain {C:blue}Foil{},',
            [3] = '{C:red}Holographic{}, or {C:edition}Polychrome{}',
            [4] = 'when scored.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_triggerh_fortuneiii') 
        return {vars = {card.ability.extra.random, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_stone"] == true and context.other_card.edition == nil and (card.ability.extra.random or 0) == 1) then
                card.ability.extra.random = pseudorandom('random_a52c13f5', 1, 3)
                if SMODS.pseudorandom_probability(card, 'group_0_8dabf782', 1, card.ability.extra.odds, 'j_triggerh_fortuneiii', false) then
              context.other_card:set_edition("e_foil", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            elseif (SMODS.get_enhancements(context.other_card)["m_stone"] == true and context.other_card.edition == nil and (card.ability.extra.random or 0) == 2) then
                card.ability.extra.random = pseudorandom('random_dc735461', 1, 3)
                if SMODS.pseudorandom_probability(card, 'group_0_6182c853', 1, card.ability.extra.odds, 'j_triggerh_fortuneiii', false) then
              context.other_card:set_edition("e_holo", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            elseif (SMODS.get_enhancements(context.other_card)["m_stone"] == true and context.other_card.edition == nil and (card.ability.extra.random or 0) == 3) then
                card.ability.extra.random = pseudorandom('random_51028e9a', 1, 3)
                if SMODS.pseudorandom_probability(card, 'group_0_d72d3430', 1, card.ability.extra.odds, 'j_triggerh_fortuneiii', false) then
              context.other_card:set_edition("e_polychrome", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            end
        end
    end
}
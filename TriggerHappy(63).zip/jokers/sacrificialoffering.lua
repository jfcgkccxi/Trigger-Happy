SMODS.Joker{ --Sacrificial Offering
    key = "sacrificialoffering",
    config = {
        extra = {
            thing = 6,
            Spectral = 0
        }
    },
    loc_txt = {
        ['name'] = 'Sacrificial Offering',
        ['text'] = {
            [1] = '{C:red}Destroying {}an {C:attention}Enhanced {}card',
            [2] = '6 times creates a {X:legendary,C:white}Soul{} Card',
            [3] = '({C:inactive}#1# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.thing}}
    end,

    calculate = function(self, card, context)
        if context.remove_playing_cards  and not context.blueprint then
            if (function()
    for k, removed_card in ipairs(context.removed) do
        local enhancements = SMODS.get_enhancements(removed_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
    end
    return false
end)() then
                return {
                    message = "-1",
                    extra = {
                        func = function()
                    card.ability.extra.thing = math.max(0, (card.ability.extra.thing) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            end
        end
        if context.hand_drawn  and not context.blueprint then
            if (card.ability.extra.thing or 0) <= 1 then
                return {
                    func = function()
                    card.ability.extra.thing = 6
                    return true
                end,
                    extra = {
                        func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Spectral', key = 'c_soul', key_append = 'joker_forge_spectral'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "YOUR OFFERING IS ACCEPTED...", colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end,
                        colour = G.C.SECONDARY_SET.Spectral
                        }
                }
            end
        end
        if context.using_consumeable  and not context.blueprint then
            if (card.ability.extra.thing or 0) <= 1 then
                return {
                    func = function()
                    card.ability.extra.thing = 6
                    return true
                end,
                    extra = {
                        func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Spectral', key = 'c_soul', key_append = 'joker_forge_spectral'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "YOUR OFFERING IS ACCEPTED...", colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end,
                        colour = G.C.SECONDARY_SET.Spectral
                        }
                }
            end
        end
    end
}
SMODS.Joker{ --Beowulf
    key = "beowulf",
    config = {
        extra = {
            power = 8,
            Xmult = 8
        }
    },
    loc_txt = {
        ['name'] = 'Beowulf',
        ['text'] = {
            [1] = 'Every 8th {C:attention}10{}',
            [2] = 'scores {X:red,C:white}X8{}',
            [3] = '({C:inactive}#1# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.power}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 10 and (card.ability.extra.power or 0) > 1) then
                card.ability.extra.power = math.max(0, (card.ability.extra.power) - 1)
            elseif (context.other_card:get_id() == 10 and (card.ability.extra.power or 0) <= 1) then
                card.ability.extra.power = 8
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}
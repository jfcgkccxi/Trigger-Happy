SMODS.Joker{ --Arthur
    key = "zzzarthur",
    config = {
        extra = {
            pb_h_x_mult_31f58e9f = 0.05,
            pb_x_mult_fd3679bf = 0.05,
            perma_h_x_mult = 0,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Arthur',
        ['text'] = {
            [1] = 'Scored {C:attention}Steel{} cards',
            [2] = 'gain {X:red,C:white}X0.05{} to held',
            [3] = 'and scored value'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 9,
        y = 0
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                context.other_card.ability.perma_h_x_mult = context.other_card.ability.perma_h_x_mult or 0
                context.other_card.ability.perma_h_x_mult = context.other_card.ability.perma_h_x_mult + card.ability.extra.pb_h_x_mult_31f58e9f
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_fd3679bf
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
                }
            end
        end
    end
}
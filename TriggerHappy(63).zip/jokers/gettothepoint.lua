SMODS.Joker{ --Get To The Point
    name = "Get To The Point",
    key = "gettothepoint",
    config = {
        extra = {
            handmult = 0,
            handsremaining = 0,
            hands = 1
        }
    },
    loc_txt = {
        ['name'] = 'Get To The Point',
        ['text'] = {
            [1] = 'Reduces {C:blue}Hands {}to 1.',
            [2] = 'Gains {X:red,C:white}X1.5{} Mult',
            [3] = 'for each hand.',
            [4] = '(Currently {X:red,C:white}X#1#{})'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.handmult}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind and not context.blueprint then
                local handmult_value = card.ability.extra.handmult
                return {
                    func = function()
                    card.ability.extra.handmult = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.handmult = (card.ability.extra.handmult) + (G.GAME.current_round.hands_left) * 1.5
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(card.ability.extra.hands).." Hands", colour = G.C.BLUE})
                G.GAME.current_round.hands_left = card.ability.extra.hands
                return true
            end,
                            colour = G.C.GREEN
                        }
                        }
                }
        end
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    Xmult = card.ability.extra.handmult
                }
        end
    end
}
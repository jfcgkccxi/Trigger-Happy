SMODS.Joker{ --+4
    key = "_4",
    config = {
        extra = {
            discard_change = 1,
            plus4 = 0,
            bpcounter = 0,
            hand_size = 4,
            hand_size3 = 4,
            hand_size4 = 4
        }
    },
    loc_txt = {
        ['name'] = '+4',
        ['text'] = {
            [1] = '{C:red}-1 Discard{}.',
            [2] = '{C:attention}+4{} Hand size on',
            [3] = '{C:blue}final hand{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.plus4 or 0) == 1 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.hand_size)
                return true
            end,
                    extra = {
                        func = function()
                    card.ability.extra.plus4 = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
        if context.selling_self  and not context.blueprint then
            if (card.ability.extra.plus4 or 0) == 1 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.bpcounter).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.bpcounter)
                return true
            end
                }
            end
        end
        if context.hand_drawn  and not context.blueprint then
            if ((card.ability.extra.plus4 or 0) == 0 and G.GAME.current_round.hands_left == 1) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size3).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size3)
                return true
            end,
                    extra = {
                        func = function()
                    card.ability.extra.plus4 = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            elseif (G.hand.config.card_limit <= 8 and (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_guts" then
              return false
          end
      end
      return true
  end)() and (card.ability.extra.plus4 or 0) == 1) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size4).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size4)
                return true
            end
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.GAME.round_resets.discards = math.max(0, G.GAME.round_resets.discards - card.ability.extra.discard_change)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.extra.discard_change
    end
}
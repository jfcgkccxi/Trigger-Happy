SMODS.Joker{ --Quarterly Budget
    key = "quarterlybudget",
    config = {
        extra = {
            currentante = 0
        }
    },
    loc_txt = {
        ['name'] = 'Quarterly Budget',
        ['text'] = {
            [1] = 'Sets money to {C:money}$#1#{} upon',
            [2] = 'defeating the Boss Blind.',
            [3] = 'Gains {C:money}$5{} per {C:attention}Ante{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {((G.GAME.round_resets.ante or 0)) * 5}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  and not context.blueprint then
                return {
                    func = function()
                    local target_amount = (G.GAME.round_resets.ante) * 5
                    local current_amount = G.GAME.dollars
                    local difference = target_amount - current_amount
                    ease_dollars(difference)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring((G.GAME.round_resets.ante) * 5), colour = G.C.MONEY})
                    return true
                end
                }
        end
    end
}
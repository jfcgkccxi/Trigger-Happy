SMODS.Joker{ --Order
    key = "zz3order",
    config = {
        extra = {
            source_rank_type = "all",
            target_rank = "8",
            source_rank_type = "all",
            target_rank = "9",
            source_rank_type = "all",
            target_rank = "10",
            source_rank_type = "all",
            target_rank = "J",
            source_rank_type = "all",
            target_rank = "Q",
            source_rank_type = "all",
            target_rank = "K",
            source_rank_type = "all",
            target_rank = "A",
            source_rank_type = "all",
            target_rank = "2",
            source_rank_type = "all",
            target_rank = "3",
            source_rank_type = "all",
            target_rank = "4",
            source_rank_type = "all",
            target_rank = "5",
            source_rank_type = "all",
            target_rank = "6",
            source_rank_type = "all",
            target_rank = "7"
        }
    },
    loc_txt = {
        ['name'] = 'Order',
        ['text'] = {
            [1] = '{C:dark_edition}All ranks{} are',
            [2] = 'the {C:red}same{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 8
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 9
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 10
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 11
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 12
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 13
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 14
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 2
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 3
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 4
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 5
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 6
    end
    if next(SMODS.find_card("j_triggerh_zz3order")) then
        return 7
    end
    return original_id
end

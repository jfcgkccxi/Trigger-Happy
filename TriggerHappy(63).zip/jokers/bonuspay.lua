SMODS.Joker{ --Bonus Pay
    key = "bonuspay",
    config = {
        extra = {
            pay = 1,
            counter = 1
        }
    },
    loc_txt = {
        ['name'] = 'Bonus Pay',
        ['text'] = {
            [1] = '{C:money}$#1#{} per round.',
            [2] = 'Scales with {C:attention}Bonus{} cards scored.',
            [3] = 'Required cards scales with pay.',
            [4] = '({C:inactive}#2# Remaining{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.pay, card.ability.extra.counter}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if (SMODS.get_enhancements(context.other_card)["m_bonus"] == true and (card.ability.extra.counter or 0) > 1) then
                card.ability.extra.counter = (card.ability.extra.counter) + -1
            elseif (SMODS.get_enhancements(context.other_card)["m_bonus"] == true and (card.ability.extra.counter or 0) <= 1) then
                local counter_value = card.ability.extra.counter
                card.ability.extra.counter = (card.ability.extra.counter) + -1
                card.ability.extra.pay = (card.ability.extra.pay) + 1
                card.ability.extra.counter = (card.ability.extra.counter) + card.ability.extra.pay
                return {
                    message = "Bonus!"
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    dollars = card.ability.extra.pay
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.counter or 0) <= -10000 then
                card.ability.extra.pay = (card.ability.extra.pay) + 1
                card.ability.extra.counter = (card.ability.extra.counter) + card.ability.extra.pay
                return {
                    message = "Bonus!"
                }
            end
        end
    end
}